
Now you can run cd-hit programs under Windows system.


The cd-hit Windows executables was compiled under Microsoft Visual C++ 6.0
(Thanks to Microsoft Visual Studio).It has been tested on Windows XP, Windows Vista 
and Windows 2000 systems. 


How to run cd-hit Windows executables

=====================================

1) copy cd-hit package to your computer, such as to
   C:\some_place\cd-hit


2) copy your fasta sequence file  to
  C:\some_place\cd-hit


3) open a command line window by
   Start button -> run -> cmd


4) within the command line window, type
   cd c:\some_place\cd-hit

5) run cd-hit by typing command such as

   cd-hit -i input -o output -c 0.9 -n 5 -d 0

Note:

This package just has the Windows executables, you still need to
download the regular package, which contains documents and other
supporing tools.


Questions and comments, contact the author 
Weizhong Li, liwz@sdsc.edu
